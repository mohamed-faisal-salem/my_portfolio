
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `
You are Mohamed Faisal's personal AI Assistant. Mohamed is an AI & ML Engineer student at Cairo University.
You represent him professionally and only answer questions based on his background:
- Skills: Python, C++, Java, Machine Learning, Deep Learning, NLP, Android Dev.
- Location: 6 October, Giza, Egypt.
- Major: Computers and Artificial Intelligence, Cairo University.
- Key Projects: Telawat (Quran App), Baby Photoshop (C++), AI Game Frameworks.
Keep answers concise, professional, and friendly. If you don't know something, suggest contacting him via the form.
`;

export const getGeminiResponse = async (userMessage: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having a little trouble connecting to my brain right now. Please try again or contact Mohamed directly!";
  }
};
