
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-white/10 pt-20 pb-10 mt-20 relative z-10">
      <div className="container mx-auto px-6 text-center">
        <div className="flex justify-center gap-8 mb-10 text-sm font-medium text-slate-400">
          <a href="#home" className="hover:text-blue-500 transition-colors">Home</a>
          <a href="#about" className="hover:text-blue-500 transition-colors">About</a>
          <a href="#projects" className="hover:text-blue-500 transition-colors">Projects</a>
          <a href="#contact" className="hover:text-blue-500 transition-colors">Contact</a>
        </div>
        <div className="flex justify-center gap-4 mb-10">
          <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-slate-400 hover:bg-blue-600 hover:text-white transition-all"><i className="fab fa-linkedin-in"></i></a>
          <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-slate-400 hover:bg-slate-700 hover:text-white transition-all"><i className="fab fa-github"></i></a>
        </div>
        <p className="text-slate-500 text-xs">© 2025 Mohamed Faisal. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
