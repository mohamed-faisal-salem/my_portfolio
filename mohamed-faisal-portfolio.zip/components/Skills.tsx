
import React from 'react';

const SkillCard: React.FC<{ title: string; icon: string; skills: string[] }> = ({ title, icon, skills }) => (
  <div className="glass p-8 rounded-2xl hover:-translate-y-2 transition-transform duration-300 border border-white/5">
    <div className="text-blue-500 text-4xl mb-6">
      <i className={icon}></i>
    </div>
    <h3 className="text-xl font-bold mb-4">{title}</h3>
    <ul className="space-y-2 text-slate-400">
      {skills.map((skill, idx) => (
        <li key={idx} className="flex items-center gap-2">
          <span className="text-blue-500 text-xs">▹</span> {skill}
        </li>
      ))}
    </ul>
  </div>
);

const Skills: React.FC = () => {
  const skillSets = [
    {
      title: 'Programming',
      icon: 'fas fa-code',
      skills: ['Python', 'C++', 'Java', 'Data Structures', 'Algorithms', 'OOP']
    },
    {
      title: 'AI & Data Science',
      icon: 'fas fa-brain',
      skills: ['Machine Learning', 'Deep Learning', 'NLP', 'TensorFlow', 'Scikit-learn']
    },
    {
      title: 'Tools & Dev',
      icon: 'fas fa-tools',
      skills: ['Android Studio', 'Git / GitHub', 'Firebase', 'VS Code', 'JUCE Framework']
    },
    {
      title: 'Soft Skills',
      icon: 'fas fa-user-check',
      skills: ['Technical Writing', 'Problem Solving', 'Teamwork', 'Critical Thinking']
    }
  ];

  return (
    <section id="skills" className="scroll-mt-24">
      <h2 className="text-4xl font-bold mb-12 relative inline-block">
        Skills
        <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-blue-500 rounded-full"></span>
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {skillSets.map((set, idx) => (
          <SkillCard key={idx} {...set} />
        ))}
      </div>
    </section>
  );
};

export default Skills;
