
import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [status, setStatus] = useState<null | 'success' | 'error'>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // In a real scenario, this would call our Express backend
    console.log('Sending message:', formData);
    setStatus('success');
    setTimeout(() => setStatus(null), 5000);
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <section id="contact" className="scroll-mt-24">
      <h2 className="text-4xl font-bold mb-12 relative inline-block">
        Connect With Me
        <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-blue-500 rounded-full"></span>
      </h2>
      <div className="grid lg:grid-cols-2 gap-12">
        <div className="glass p-10 rounded-3xl space-y-10">
          <div className="space-y-6">
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-500 text-2xl">
                <i className="fas fa-phone-alt"></i>
              </div>
              <div>
                <p className="text-slate-500 text-sm font-bold uppercase">Phone</p>
                <p className="text-xl font-medium">+20 106 394 1971</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-500 text-2xl">
                <i className="fas fa-map-marker-alt"></i>
              </div>
              <div>
                <p className="text-slate-500 text-sm font-bold uppercase">Location</p>
                <p className="text-xl font-medium">6 October, Giza, Egypt</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-500 text-2xl">
                <i className="fab fa-google"></i>
              </div>
              <div>
                <p className="text-slate-500 text-sm font-bold uppercase">Gmail</p>
                <p className="text-xl font-medium">engmohamedfaisal06@gmail.com</p>
              </div>
            </div>
          </div>
          <div className="flex gap-4">
            <a href="https://linkedin.com" target="_blank" className="w-12 h-12 rounded-xl glass flex items-center justify-center text-xl text-slate-300 hover:text-blue-500 hover:border-blue-500/50 transition-all"><i className="fab fa-linkedin-in"></i></a>
            <a href="https://github.com" target="_blank" className="w-12 h-12 rounded-xl glass flex items-center justify-center text-xl text-slate-300 hover:text-white hover:border-white/50 transition-all"><i className="fab fa-github"></i></a>
          </div>
        </div>

        <div className="glass p-10 rounded-3xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-500 uppercase">Name</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-all"
                  placeholder="John Doe"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-500 uppercase">Email</label>
                <input 
                  type="email" 
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-all"
                  placeholder="john@example.com"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-500 uppercase">Subject</label>
              <input 
                type="text" 
                value={formData.subject}
                onChange={(e) => setFormData({...formData, subject: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-all"
                placeholder="Business Inquiry"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-500 uppercase">Message</label>
              <textarea 
                rows={4}
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500 transition-all resize-none"
                placeholder="How can I help you?"
                required
              />
            </div>
            <button 
              type="submit" 
              className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold hover:shadow-2xl hover:shadow-blue-500/30 hover:-translate-y-1 transition-all"
            >
              <i className="fas fa-paper-plane mr-2"></i> Send Message
            </button>
            {status === 'success' && <p className="text-center text-green-500 font-bold">Message sent successfully!</p>}
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;
