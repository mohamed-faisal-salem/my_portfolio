
import React from 'react';
import { Project } from '../types';

const ProjectCard: React.FC<Project> = (project) => (
  <div className="glass rounded-3xl overflow-hidden group flex flex-col h-full border border-white/5 hover:border-blue-500/30 transition-all duration-500">
    <div className={`h-48 flex items-center justify-center text-white text-5xl bg-gradient-to-br ${project.gradient}`}>
      <i className={project.icon}></i>
    </div>
    <div className="p-8 flex flex-col flex-grow">
      <h3 className="text-2xl font-bold mb-4">{project.title}</h3>
      <p className="text-slate-400 leading-relaxed mb-6 flex-grow">{project.description}</p>
      <div className="flex flex-wrap gap-2 mb-8">
        {project.tags.map(tag => (
          <span key={tag} className="px-3 py-1 rounded-full bg-blue-500/5 text-blue-400 text-xs font-bold border border-blue-500/10">
            {tag}
          </span>
        ))}
      </div>
      <div className="flex gap-4 mt-auto">
        {project.link && (
          <a href={project.link} target="_blank" className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-center font-bold text-sm hover:bg-blue-600 hover:border-blue-500 transition-all">
            <i className="fas fa-external-link-alt mr-2"></i> Live Demo
          </a>
        )}
        {project.github && (
          <a href={project.github} target="_blank" className="flex-1 py-3 rounded-xl bg-slate-800 border border-white/5 text-center font-bold text-sm hover:bg-slate-700 transition-all">
            <i className="fab fa-github mr-2"></i> GitHub
          </a>
        )}
      </div>
    </div>
  </div>
);

const Projects: React.FC = () => {
  const projects: Project[] = [
    {
      id: '1',
      title: 'Telawat - Quran App',
      description: 'Production Android app with 200+ reciters, streaming, and offline downloads. Uses Firebase and Material Design.',
      tags: ['Java', 'Firebase', 'Android Studio'],
      link: 'https://play.google.com/store/apps/details?id=com.aap.quraankareem',
      github: 'https://github.com/mohamed-faisal-salem/Telawat.git',
      icon: 'fas fa-mobile-alt',
      gradient: 'from-emerald-500 to-blue-600'
    },
    {
      id: '2',
      title: 'Baby Photoshop',
      description: 'C++ image processor with 12+ advanced filters including edge detection and noise reduction.',
      tags: ['C++', 'Image Processing', 'OOP'],
      github: 'https://github.com/mohamed-faisal-salem/CS213-OOP-Programming-Assignment1.git',
      icon: 'fas fa-image',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      id: '3',
      title: 'AI Game Framework',
      description: 'Extensible Tic-Tac-Toe variants implementing Minimax with Alpha-Beta pruning for intelligent opponents.',
      tags: ['C++', 'Artificial Intelligence', 'Algorithms'],
      github: 'https://github.com/mohamed-faisal-salem/CS213-OOP-Programming-Assignment3.git',
      icon: 'fas fa-gamepad',
      gradient: 'from-blue-500 to-purple-600'
    }
  ];

  return (
    <section id="projects" className="scroll-mt-24">
      <h2 className="text-4xl font-bold mb-12 relative inline-block">
        Featured Projects
        <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-blue-500 rounded-full"></span>
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map(p => <ProjectCard key={p.id} {...p} />)}
      </div>
    </section>
  );
};

export default Projects;
