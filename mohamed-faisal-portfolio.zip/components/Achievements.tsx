
import React from 'react';
import { Achievement } from '../types';

const AchievementCard: React.FC<Achievement> = (achievement) => (
  <div className={`glass p-8 rounded-2xl border-l-4 hover:shadow-2xl hover:shadow-blue-500/10 transition-all flex flex-col h-full`} style={{ borderLeftColor: achievement.gradient.split(' ')[1] }}>
    <div className="flex justify-between items-start mb-6">
      <div className="px-3 py-1 rounded-full text-xs font-bold text-white uppercase tracking-wider bg-gradient-to-r from-yellow-500 to-orange-600">
        {achievement.rank}
      </div>
      <div className="text-blue-400 text-sm flex items-center gap-1">
        <i className="fab fa-kaggle"></i> Kaggle
      </div>
    </div>
    <div className="w-12 h-12 rounded-lg bg-blue-600/20 flex items-center justify-center text-blue-500 text-2xl mb-4">
      <i className={achievement.icon}></i>
    </div>
    <h3 className="text-xl font-bold mb-2">{achievement.title}</h3>
    <p className="text-slate-400 text-sm mb-6 flex-grow">{achievement.description}</p>
    <div className="flex flex-wrap gap-2 mb-6">
      {achievement.skills.map(skill => (
        <span key={skill} className="px-2 py-1 rounded-md bg-white/5 text-[10px] font-medium text-slate-300 border border-white/5">
          {skill}
        </span>
      ))}
    </div>
    <a href={achievement.link} target="_blank" className="text-blue-400 hover:text-blue-300 text-sm font-semibold flex items-center gap-2">
      View Competition <i className="fas fa-arrow-right"></i>
    </a>
  </div>
);

const Achievements: React.FC = () => {
  const achievements: Achievement[] = [
    {
      id: '1',
      title: 'House Prices Competition',
      // Fix: Added missing required 'badge' property
      badge: 'Expert',
      rank: 'Top 4% Globally',
      platform: 'Kaggle',
      description: 'Applied advanced regression and feature engineering to predict residential home prices with exceptional accuracy.',
      skills: ['Regression', 'XGBoost', 'Feature Engineering'],
      link: 'https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques',
      icon: 'fas fa-home',
      gradient: 'linear-gradient(to right, #f59e0b, #d97706)'
    },
    {
      id: '2',
      title: 'Titanic ML Competition',
      // Fix: Added missing required 'badge' property
      badge: 'Contributor',
      rank: 'Top 25% Globally',
      platform: 'Kaggle',
      description: 'Implemented classification algorithms to predict passenger survival, developing strong preprocessing skills.',
      skills: ['Classification', 'Random Forest', 'Data Preprocessing'],
      link: 'https://www.kaggle.com/competitions/titanic',
      icon: 'fas fa-ship',
      gradient: 'linear-gradient(to right, #8b5cf6, #7c3aed)'
    }
  ];

  return (
    <section id="achievements" className="scroll-mt-24">
      <h2 className="text-4xl font-bold mb-12 relative inline-block">
        Achievements
        <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-blue-500 rounded-full"></span>
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {achievements.map(a => <AchievementCard key={a.id} {...a} />)}
      </div>
    </section>
  );
};

export default Achievements;
