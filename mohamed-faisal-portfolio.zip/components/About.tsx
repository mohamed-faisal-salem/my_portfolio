
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="scroll-mt-24">
      <h2 className="text-4xl font-bold mb-12 relative inline-block">
        About Me
        <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-blue-500 rounded-full"></span>
      </h2>
      <div className="glass rounded-2xl overflow-hidden grid md:grid-cols-2 gap-8 items-center p-8">
        <div className="space-y-6">
          <p className="text-lg text-slate-300 leading-relaxed">
            I am a student at the Faculty of Computers and Artificial Intelligence, Cairo University, driven by the challenge of building systems that simulate human intelligence.
          </p>
          <p className="text-lg text-slate-300 leading-relaxed">
            My journey focuses on **Deep Learning** and **NLP**, where I bridge theoretical concepts with industry-level implementations. I specialize in C++, Python, and building production-ready Android applications.
          </p>
          <div className="pt-4">
            <button className="px-6 py-3 rounded-xl bg-slate-800 text-slate-500 cursor-not-allowed border border-white/10 flex items-center gap-2">
              <i className="fas fa-download"></i> Download CV (Coming Soon)
            </button>
          </div>
        </div>
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
          <div className="relative aspect-square rounded-2xl overflow-hidden shadow-2xl">
            <img 
              src="https://picsum.photos/id/1/600/600" 
              alt="Mohamed Faisal" 
              className="w-full h-full object-cover transform transition-transform group-hover:scale-105"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
